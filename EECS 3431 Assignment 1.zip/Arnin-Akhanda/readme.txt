All elements which have been sucessfully implemented include: 

- the use of real time to synchronize all animations

- Ground box

- two rocks depicted by spheres

- successful positioning and animation of three seaweed strands, each containing 10 ellipses, each of which are identical and have exact same movements 

- successful modeling and animation of fish including of 2 eyes with pupils, 1 head, 1 body, 2 tail fins which swim around the tangent of a cirlce around the seaweed while also moving up and down 

- sucessful animation of a burst of 4-5 bubbles which appear close to the mouth every few seconds, oscilate with time  and are removed after 12 seconds which start to move at the same time at which they appear 

-sucessful modelling and animation of human diver with no arms which moves only in x and y directions, the divers legs (but not feet) also move according to the video, all parts of the body appear attached and do not appear to be broken apart

- successful screen dimensions of 512x512

- adequate comments and functions for easy understanding of code 

